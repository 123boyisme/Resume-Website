﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
    public float moveSpeed;
    private Rigidbody myRigidBody;

    private Vector3 moveImput;
    private Vector3 moveVelocity;

    private Camera mainCam;

    public GunController gun;
    public GunController gunOne;
    // Use this for initialization
    void Start () {
        myRigidBody = GetComponent<Rigidbody>();
        mainCam = FindObjectOfType<Camera>();
	}
	
	// Update is called once per frame
	void Update () {
        //player movement stuff
        moveImput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
        moveVelocity = moveImput * moveSpeed;

        //make player face the cam
        Ray cameraRay = mainCam.ScreenPointToRay(Input.mousePosition);
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
        float rayLength;

        if (groundPlane.Raycast(cameraRay, out rayLength))
        {
            Vector3 pointToLookAt = cameraRay.GetPoint(rayLength);
            Debug.DrawLine(cameraRay.origin, pointToLookAt, Color.blue);
            transform.LookAt(new Vector3(pointToLookAt.x, transform.position.y, pointToLookAt.z));
        }
        //------------------------------------------------------------------------
        //shooting the gun
        if (Input.GetMouseButtonDown(0))
        {
            gun.isShooting = true;
        }

        if (Input.GetMouseButtonUp(0))
        { 
            gun.isShooting = false;
        }



    }
    void FixedUpdate()
    {
        //player movement
        myRigidBody.velocity = moveVelocity;  
    }
}
