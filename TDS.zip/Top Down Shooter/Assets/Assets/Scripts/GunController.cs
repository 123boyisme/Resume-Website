﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour {
    public bool isShooting;

    public BulletController bullet;
    public float bulletSpeed;

    public float timeBetweenBullets;
    private float shotCounter;

    public Transform firePoint;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //check if the bullet is shooting
        if (isShooting)
        {
            shotCounter -= Time.deltaTime;
            //if it is then wait until shot counter is at 0 before resetting
            if (shotCounter <= 0)
            {
                shotCounter = timeBetweenBullets;
                BulletController newBullet = Instantiate(bullet, firePoint.position, firePoint.rotation) as BulletController;
             
                newBullet.speed = bulletSpeed;
            }
        }
        else
        {
            //if not shooting do nothing    
            shotCounter = 0;
        } 
	}
}
