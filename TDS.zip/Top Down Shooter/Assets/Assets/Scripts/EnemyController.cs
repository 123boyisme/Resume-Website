﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {
    private Rigidbody myRigidBody;
    public float moveSpeed;
    public PlayerController player;
	// Use this for initialization
	void Start () {
        myRigidBody = GetComponent<Rigidbody>();
        player = FindObjectOfType<PlayerController>(); 
    }
	
	// Update is called once per frame
	void Update () {
        transform.LookAt(player.transform.position);
	}
    void FixedUpdate()
    {
        myRigidBody.velocity = (transform.forward * moveSpeed);
        
    }
}
