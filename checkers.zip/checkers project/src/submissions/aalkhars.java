package submissions;
import checkers.AbstractEvaluator;

/**
 * student skeleton
 * change Class name to first initial, last name
 * of one of the students in the team
 * e.g. student Bob Smith -> BSmith
 */
public class aalkhars extends AbstractEvaluator {

    /*
     * Helper methods:
     * Each method listed here take in one spot on the board (a char), and
     * returns a boolean (true or false) based on if the info checking is
     * valid for that specific tile
     * 
     * methodName (parameters):  information checking
     * ownChecker (char tile):   own regular checker pieces
     * ownKing    (char tile):   own king checker pieces
     * oppChecker (char tile):   opponent's regular checker pieces
     * oppKing    (char tile):   opponent's king checker pieces
     */

    public aalkhars() { //also change constructor name

        //change theses values
        super.name = "cheese"; //set equal to your team name
        super.section = -1;  //set equal to lab section
    }

    /*
     * Board layout
     * Rows close to row 0 is Evaluator's
     * side of the board, while close to row 9 is the opponenent's
     */

    @Override
    public int evaluateBoard(char [][] board) {
    	int boardScore=0;
    	//total piecec on each side
        for(int i = 0; i < board.length;i++) {
	        for(int j = 0; j<board[i].length;j++) {
		        if(ownChecker(board[i][j])) {
		        	boardScore++;
		        }
		        if(ownKing(board[i][j])) {
		        	boardScore+=2;
		        }
		        if(oppChecker(board[i][j])) {
		        	boardScore--;
		        }
		        if(oppKing(board[i][j])) {
		        	boardScore-=2;
		        }
	        }
        }
        //checks for back line
        for(int i = 0; i < board.length;i++) {
        	if(ownChecker(board[0][i])) {
        		boardScore++;
        	}
        }
        for(int i = 0; i < board.length;i++) {
        	if(ownChecker(board[8][i])) {
        		boardScore--;
        	}
        }
        //pyramid pattern
        if(ownChecker(board[0][2])) {
        	if(ownChecker(board[0][4])){
        		if(ownChecker(board[0][6])){
        			if(ownChecker(board[0][8])){
        				if(ownChecker(board[1][3])){
        					if(ownChecker(board[1][5])){
        						if(ownChecker(board[2][4])) {
        							boardScore+=10;
        						}
        					}
        				}
        			}
        		}
        	}
        }
        if(ownChecker(board[7][1])) {
        	if(oppChecker(board[7][3])){
        		if(oppChecker(board[7][5])){
        			if(oppChecker(board[7][7])){
        				if(oppChecker(board[6][4])){
        					if(oppChecker(board[6][6])){
        						if(oppChecker(board[5][5])) {
        							boardScore-=10;
        						}
        					}
        				}
        			}
        		}
        	}
        }
        //check who center is owned by
        int center = 0;
        for(int i=3; i< 7;i++) {
        	if(ownChecker(board[4][i])) {
        		center++;
        	}
        	if(ownChecker(board[4][i])) {
        		center++;
        	}
        	if(ownChecker(board[5][i])) {
        		center++;
        	}
        	if(ownChecker(board[5][i])) {
        		center++;
        	}
        }
        for(int i=3; i< 7;i++) {
        	if(oppChecker(board[4][i])) {
        		center--;
        	}
        	if(oppChecker(board[4][i])) {
        		center--;
        	}
        	if(oppChecker(board[5][i])) {
        		center--;
        	}
        	if(!oppChecker(board[5][i])) {
        		center--;
        	}
        }
        
        boardScore+=center;
        //check for captures
        for(int i = 0; i < board.length;i++) {
	        for(int j = 0; j<board[i].length;j++) {
	        	if(ownChecker(board[i][j])) {
	        		if(oppChecker(board[i+1][j+1])&&j+1<=7&&(i+1)<=7) {
	        			if(emptySpace(board,i+2,j+2)&&i+2<=7&&j+2<=7) {
	        				boardScore++;
	        			}
	        		}
	        		if(oppChecker(board[i+1][j-1])&&j-1>=0&&(i+1)<=0) {
	        			if(emptySpace(board,i+2,j-2)&&i+2<=7&&j-2>=0) {
	        				boardScore++; 
	        			}
	        		}
	        	}
	        }
        }
        return boardScore; //return will be your final board score
    }
    public boolean emptySpace(char[][] board, int row, int col) {
    	if(!oppChecker(board[row][col])&&!ownChecker(board[row][col])) {
    		return true;
    	}
    	return false;
    }


}

